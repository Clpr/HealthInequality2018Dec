rm(list = ls(all = TRUE))


library(ggplot2)
library(maptools)
library(mapproj)
library(dplyr)
library(RColorBrewer)

##���Ƶ�ͼ
#�����й���ͼ
mydat <- readShapePoly("bou2_4p.shp")

mymap <- ggplot(data = fortify(mydat)) + 
         geom_polygon(aes(x = long, y = lat, group = group), colour = "white", fill = "grey80") + 
         labs(x = "Longitude", y = "Latitude", hjust = 0.5) + coord_map() + theme_grey() + theme(plot.title = element_text(hjust = 0.5))

print(mymap)


## �ڵ�ͼ�ϻ��Ƴ���λ�á����е�ָ��ֵ
citymean <- read.csv("city mean.csv", header = TRUE,fileEncoding = "GBK")

# ���˾�GDP���˾�̼�ŷ�����ͼ
# ��GDPP����
cutpoint <- quantile(citymean$gdpp)
cutpoint

cutpoint <- c(8000,15000,20000,35000,50000)
citymean$group.gdpp <- ifelse(citymean$gdpp < cutpoint[2],2,ifelse(citymean$gdpp < cutpoint[3],4,ifelse(citymean$gdpp < cutpoint[4], 6, 8)))

citymean$group.gdpp <- as.factor(citymean$group.gdpp)
#��ͼ
mycolor=brewer.pal(9,"Blues")
cityLocation <- mymap + geom_point(data=citymean, aes(x = long, y = lat, group = group.gdpp, color = group.gdpp), shape = 16,size=log(citymean$carp/2000))  +
  labs(x = "Longtitudes", y = "Latitudes", color = "GDP per capita") +
  scale_color_manual(values = mycolor[c(3,5,7,9)],labels = c("< 15000", "15000 - 20000", "20000 - 35000", "> 35000")) +
  theme_bw() + 
  theme(legend.position = c(0.23,0.20), legend.background = element_rect(fill = "white", color = "black"))
# ��ʾ��ͼ
print(cityLocation)


# ���������뺯��ֵ����
cutpoint <- quantile(citymean$D)
citymean$group.D <- ifelse(citymean$D < cutpoint[2],2,ifelse(citymean$D < cutpoint[3],4,ifelse(citymean$D < cutpoint[4], 6, 8)))
citymean$group.D <- as.factor(citymean$group.D)
# ��ͼ
cityD <- mymap + geom_point(data=citymean, aes(x = long, y = lat, group = group.D, color = group.D), shape = 16, size = 5)  +
  labs(x = "Longtitudes", y = "Latitudes", color = "Inefficiency") +
  scale_color_manual(values = brewer.pal(4,"PuRd"),labels = c("< 0.07", "0.07 - 0.16", "0.17 - 0.25", "> 0.25")) +
  theme_bw() + 
  theme(legend.position = c(0.23,0.20), legend.background = element_rect(fill = "white", color = "black"))
# ��ʾ��ͼ
print(cityD)

# ��Ӱ�Ӽ۸����
cutpoint <- quantile(citymean$shadowPrice)
citymean$group.Q <- ifelse(citymean$shadowPrice < cutpoint[2],2,ifelse(citymean$shadowPrice < cutpoint[3],4,ifelse(citymean$shadowPrice < cutpoint[4], 6, 8)))
citymean$group.Q <- as.factor(citymean$group.Q)
# ��ͼ
# cityQ <- mymap + geom_point(data=citymean, aes(x = long, y = lat, group = group.Q, color = group.Q), shape = 16, size = 5)  +
#   labs(x = "Longtitudes", y = "Latitudes", color = "Shadow Price") +
#   scale_color_manual(values = brewer.pal(4,"Blues"),labels = c("< 0.62", "0.62 - 0.65", "0.66 - 0.72", "> 0.72")) +
#   theme_bw() + 
#   theme(legend.position = c(0.23,0.20), legend.background = element_rect(fill = "white", color = "black"))
cityQ <- mymap + geom_point(data=citymean, aes(x = long, y = lat, group = group.Q, color = group.Q), shape = 16, size = 4*log(citymean$abatementCost+1))  +
  labs(x = "Longtitudes", y = "Latitudes", color = "Shadow Price") +
  scale_color_manual(values = brewer.pal(4,"Blues"),labels = c("< 0.62", "0.62 - 0.65", "0.66 - 0.72", "> 0.72")) +
  theme_bw() + 
  theme(legend.position = c(0.23,0.20), legend.background = element_rect(fill = "white", color = "black"))
# ��ʾ��ͼ
print(cityQ)

# �����ųɱ�����
cutpoint <- quantile(citymean$abatementCost)
citymean$group.Cost <- ifelse(citymean$abatementCost < cutpoint[2],2,ifelse(citymean$abatementCost < cutpoint[3],4,ifelse(citymean$abatementCost < cutpoint[4], 6, 8)))
citymean$group.Cost <- as.factor(citymean$group.Cost)
# ��ͼ
cityCost <- mymap + geom_point(data=citymean, aes(x = long, y = lat, group = group.Cost, color = group.Cost), shape = 16, size = 5)  +
  labs(x = "Longtitudes", y = "Latitudes", color = "Abatement Cost") +
  scale_color_manual(values = brewer.pal(4,"Reds"),labels = c("< 0.24", "0.24 - 0.47", "0.48 - 0.98", "> 0.98")) +
  theme_bw() + 
  theme(legend.position = c(0.23,0.20), legend.background = element_rect(fill = "white", color = "black"))
# ��ʾ��ͼ
print(cityCost)



## �������ͼƬ
ggsave("chinamap.eps", width = 8, height = 6)

      